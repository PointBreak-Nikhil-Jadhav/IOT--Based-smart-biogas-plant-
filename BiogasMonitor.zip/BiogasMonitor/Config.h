#ifndef CONFIG_H
#define CONFIG_H

// --- Network Configuration ---
const char* WIFI_SSID = "YOUR_WIFI_SSID";         
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD"; 

// --- Sensor Pin Definitions ---
#define ONE_WIRE_BUS 2      
#define PH_PIN A0           

#endif