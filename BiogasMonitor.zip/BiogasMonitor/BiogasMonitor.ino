#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include "Config.h"
#include "Sensors.h"
#include "WebPage.h"

ESP8266WebServer server(80);

void setup() {
  Serial.begin(115200);
  setupSensors();
  
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.print("Connecting to WiFi...");
  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.print(".");
  }
  
  Serial.println("");
  Serial.println("WiFi connected!");
  Serial.print("Open this IP address in your browser: ");
  Serial.println(WiFi.localIP());

  server.on("/", []() {
    server.send_P(200, "text/html", index_html);
  });

  server.on("/data", []() {
    float t = getTemperature();
    float p = getPressure();
    float ph_val = getPH();

    String json = "{"temperature":"" + String(t, 2) + "",";
    json += ""pressure":"" + String(p, 2) + "",";
    json += ""ph":"" + String(ph_val, 2) + ""}";

    server.send(200, "application/json", json);
  });

  server.begin();
}

void loop() {
  server.handleClient();
}