#include "Sensors.h"
#include "Config.h"
#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_BMP280.h>
#include <OneWire.h>
#include <DallasTemperature.h>

OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature tempSensor(&oneWire);
Adafruit_BMP280 bmp;

void setupSensors() {
  tempSensor.begin();
  if (!bmp.begin(0x76)) { 
    Serial.println("Could not find a valid BMP280 sensor, check wiring!");
  }
}

float getTemperature() {
  tempSensor.requestTemperatures(); 
  return tempSensor.getTempCByIndex(0);
}

float getPressure() {
  return bmp.readPressure() / 100.0F; 
}

float getPH() {
  int raw_ph = analogRead(PH_PIN);
  float voltage = raw_ph * (3.3 / 1023.0); 
  return 3.5 * voltage; 
}