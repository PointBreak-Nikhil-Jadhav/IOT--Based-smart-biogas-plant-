#ifndef SENSORS_H
#define SENSORS_H

void setupSensors();
float getTemperature();
float getPressure();
float getPH();

#endif