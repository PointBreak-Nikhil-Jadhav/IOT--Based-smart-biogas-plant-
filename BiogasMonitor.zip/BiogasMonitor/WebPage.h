#ifndef WEBPAGE_H
#define WEBPAGE_H
#include <Arduino.h>

const char index_html[] PROGMEM = R"rawliteral(
<!DOCTYPE HTML><html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Smart Biogas Monitor</title>
  <style>
    body { font-family: Arial, sans-serif; text-align: center; margin: 0px auto; padding-top: 30px; background-color: #f4f4f9;}
    .card { background: white; padding: 20px; margin: 10px auto; border-radius: 10px; width: 80%; max-width: 400px; box-shadow: 0px 4px 8px rgba(0,0,0,0.1); }
    h1 { color: #2c3e50; }
    .sensor-value { font-size: 2.5rem; font-weight: bold; color: #27ae60; }
    .label { font-size: 1.2rem; color: #7f8c8d; }
  </style>
</head>
<body>
  <h1>Biogas Dashboard</h1>
  
  <div class="card">
    <div class="label">Temperature</div>
    <div class="sensor-value"><span id="temp">--</span> &deg;C</div>
  </div>

  <div class="card">
    <div class="label">Pressure</div>
    <div class="sensor-value"><span id="pres">--</span> hPa</div>
  </div>

  <div class="card">
    <div class="label">pH Level</div>
    <div class="sensor-value"><span id="ph">--</span></div>
  </div>

<script>
setInterval(function ( ) {
  fetch('/data')
    .then(response => response.json())
    .then(data => {
      document.getElementById("temp").innerText = data.temperature;
      document.getElementById("pres").innerText = data.pressure;
      document.getElementById("ph").innerText = data.ph;
    });
}, 2000);
</script>
</body>
</html>
)rawliteral";

#endif